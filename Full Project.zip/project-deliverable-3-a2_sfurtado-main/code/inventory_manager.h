#ifndef INVENTORY_MANAGER_H
#define INVENTORY_MANAGER_H

#include <mutex>
#include <vector>
#include <string>

#include "equipment.h"

class InventoryManager {
protected:
    InventoryManager() = default;

private:
    // for singleton
    static InventoryManager* instance;
    // for thread-safe singleton intialization
    static std::mutex instanceMutex;

    std::vector<Equipment*> equipmentList;

    InventoryManager(const InventoryManager&) = delete;
    InventoryManager& operator=(const InventoryManager&) = delete;

public:
    virtual ~InventoryManager() = default;

    // get singleton instance
    static InventoryManager* getInstance();
    virtual void addEquipment(Equipment* equipment);
    virtual std::vector<Equipment*>& getInventory();
    virtual void removeEquipment(const std::string& id);

    virtual bool loadInventoryFromCSV(const std::string& filePath);
    virtual bool saveInventoryToCSV(const std::string& filePath);

    static std::string trim(const std::string& str);
};

#endif // INVENTORY_MANAGER_H

#ifndef USER_H
#define USER_H

#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <iostream>
#include <memory>

class User {
protected:
    std::string username;
    std::string password;
    std::string role;

    static std::vector<std::unique_ptr<User>> users;
    static std::string filePath;

public:
    User(const std::string& uname, const std::string& pass, const std::string& userRole)
        : username(uname), password(pass), role(userRole) {}

    virtual ~User() {}

    std::string getUsername() const { return username; }

    void update(const std::string& message)  {
        std::cout << "Notification for " << username << ": " << message << std::endl;
    }

    std::string getRole() const { return role; }

    bool login(const std::string& uname, const std::string& pass) const {
        return username == uname && password == pass;
    }

    virtual void displayDetails() const = 0;

    static bool loadUsers();
    static bool saveUsers();
    static User* findUser(const std::string& uname);
    static bool validateUserPassword(const std::string& uname, const std::string& pass);
    static bool updateUserPassword(const std::string& uname, const std::string& newPass);
    static void addUser(const std::string& uname, const std::string& pass, const std::string& role);
};

// member class
class Member : public User {
public:
    Member(const std::string& uname, const std::string& pass)
        : User(uname, pass, "Member") {}

    void displayDetails() const override {
        std::cout << "Member Username: " << username << std::endl;
    }
};

// clerk class
class Clerk : public User {
public:
    Clerk(const std::string& uname, const std::string& pass)
        : User(uname, pass, "Clerk") {}

    void displayDetails() const override {
        std::cout << "Clerk Username: " << username << std::endl;
    }
};

#endif // USER_H

#ifndef EQUIPMENT_H
#define EQUIPMENT_H

#include <string>
#include <iostream>

// Base equipment class that represents general equipment with shared properties and methods.
class Equipment {
private:
    std::string damageDescription;

protected:
    std::string eID;
    std::string eName;
    std::string eType;
    float rentalCost;
    std::string reservedBy;

public:

    Equipment(const std::string& id, const std::string& name, const std::string& type, float cost)
        : eID(id), eName(name), eType(type), rentalCost(cost), reservedBy("") {}

    virtual ~Equipment() = default;

    virtual std::string getID() const = 0;
    virtual std::string getName() const = 0;
    virtual std::string getType() const = 0;
    virtual double getPrice() const = 0;
    virtual bool available() const = 0;
    virtual std::string getReservedBy() const = 0;
    virtual void reserveEquipment(const std::string& user) = 0;
    virtual void makeAvailable() = 0;
    virtual void setReservedBy(const std::string& user) = 0;


    void setName(const std::string& newName) { eName = newName; }
    void setPrice(float newPrice) { rentalCost = newPrice; }
    void setDamageDescription(const std::string& description) { damageDescription = description; }
    std::string getDamageDescription() const { return damageDescription; }

    virtual void displayDetails() const = 0;
};


// Camera class derived from Equipment with specific properties
class Camera : public Equipment {
private:
    std::string resolution;

public:
    Camera(const std::string& id, const std::string& name, float cost, const std::string& res)
        : Equipment(id, name, "Camera", cost), resolution(res) {}

    std::string getID() const override { return eID; }
    std::string getName() const override { return eName; }
    std::string getType() const override { return eType; }
    double getPrice() const override { return rentalCost; }
    bool available() const override { return reservedBy.empty(); }
    std::string getReservedBy() const override { return reservedBy; }

    void reserveEquipment(const std::string& user) override { reservedBy = user; }
    void makeAvailable() override { reservedBy.clear(); }
    void setReservedBy(const std::string& user) override { reservedBy = user; }

    void displayDetails() const override {
        std::cout << "Camera: " << eName << ", ID: " << eID
                  << ", Resolution: " << resolution
                  << ", Cost: $" << rentalCost
                  << ", Available: " << (available() ? "Yes" : "No") << std::endl;
    }
};

// Lighting class derived from Equipment with specific properties
class Lighting : public Equipment {
private:
    std::string lightType;

public:
    Lighting(const std::string& id, const std::string& name, float cost, const std::string& type)
        : Equipment(id, name, "Lighting", cost), lightType(type) {}

    std::string getID() const override { return eID; }
    std::string getName() const override { return eName; }
    std::string getType() const override { return eType; }
    double getPrice() const override { return rentalCost; }
    bool available() const override { return reservedBy.empty(); }
    std::string getReservedBy() const override { return reservedBy; }

    void reserveEquipment(const std::string& user) override { reservedBy = user; }
    void makeAvailable() override { reservedBy.clear(); }
    void setReservedBy(const std::string& user) override { reservedBy = user; }

    void displayDetails() const override {
        std::cout << "Lighting: " << eName << ", ID: " << eID
                  << ", Type: " << lightType
                  << ", Cost: $" << rentalCost
                  << ", Available: " << (available() ? "Yes" : "No") << std::endl;
    }
};

// Audio class derived from Equipment with specific properties
class Audio : public Equipment {
private:
    std::string inputType;
    std::string outputType;

public:
    Audio(const std::string& id, const std::string& name, float cost, const std::string& input, const std::string& output)
        : Equipment(id, name, "Audio", cost), inputType(input), outputType(output) {}

    std::string getID() const override { return eID; }
    std::string getName() const override { return eName; }
    std::string getType() const override { return eType; }
    double getPrice() const override { return rentalCost; }
    bool available() const override { return reservedBy.empty(); }
    std::string getReservedBy() const override { return reservedBy; }

    void reserveEquipment(const std::string& user) override { reservedBy = user; }
    void makeAvailable() override { reservedBy.clear(); }
    void setReservedBy(const std::string& user) override { reservedBy = user; }

    void displayDetails() const override {
        std::cout << "Audio: " << eName << ", ID: " << eID
                  << ", Input: " << inputType
                  << ", Output: " << outputType
                  << ", Cost: $" << rentalCost
                  << ", Available: " << (available() ? "Yes" : "No") << std::endl;
    }
};

#endif // EQUIPMENT_H

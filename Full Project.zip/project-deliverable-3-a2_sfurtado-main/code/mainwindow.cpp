#include <QTableWidgetItem>
#include <QMessageBox>
#include <set>
#include <QHeaderView>
#include <QFormLayout>
#include <QDoubleSpinBox>
#include <QFile>
#include <QDir>
#include <QTextEdit>

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "accountwindow.h"
#include "equipmentdetails.h"
#include "notification_manager.h"

MainWindow::MainWindow(const QString& username, const QString& role, QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow), manager(InventoryManager::getInstance()), currentUser(username), currentRole(role) {
    ui->setupUi(this);
    ui->equipmentTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->equipmentTable->setSelectionMode(QAbstractItemView::SingleSelection);

    ui->equipmentTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    ui->backButton->setVisible(false);

    populateInventory();
    populateCategoryComboBox();
    displayInventory(manager->getInventory());

    // hide clerk-only buttons for non-clerk roles
    if (currentRole != "Clerk") {
        ui->addButton->setVisible(false);
        ui->editButton->setVisible(false);
        ui->removeButton->setVisible(false);
        ui->logDamageButton->setVisible(false);
        ui->logReturnButton->setVisible(false);
        ui->checkPickupButton->setVisible(false);
    }

    connect(ui->backButton, &QPushButton::clicked, this, &MainWindow::on_backButton_clicked);
}

MainWindow::~MainWindow() {
    delete ui;
}

// load inventory from csv
void MainWindow::populateInventory() {
    QString filePath = QDir::currentPath() + "/inventory.csv";
    qDebug() << "Attempting to load inventory from:" << filePath;

    if (!manager->loadInventoryFromCSV(filePath.toStdString())) {
        QMessageBox::warning(this, "Error", "Failed to load inventory from file.");
    } else {
        qDebug() << "Inventory loaded successfully.";
    }
}
void MainWindow::displayInventory(const std::vector<Equipment*>& equipmentList) {
    qDebug() << "Displaying inventory. Number of items:" << equipmentList.size();

    ui->equipmentTable->setRowCount(0);

    // hide resrved by column is suer is not clerk
    bool isClerk = (currentRole == "Clerk");
    ui->equipmentTable->setColumnHidden(5, !isClerk);

    for (const auto& eq : equipmentList) {
        int row = ui->equipmentTable->rowCount();
        ui->equipmentTable->insertRow(row);

        // populate table with data
        ui->equipmentTable->setItem(row, 0, new QTableWidgetItem(QString::fromStdString(eq->getID())));
        ui->equipmentTable->setItem(row, 1, new QTableWidgetItem(QString::fromStdString(eq->getName())));
        ui->equipmentTable->setItem(row, 2, new QTableWidgetItem(QString::fromStdString(eq->getType())));
        ui->equipmentTable->setItem(row, 3, new QTableWidgetItem("$" + QString::number(eq->getPrice(), 'f', 2)));
        ui->equipmentTable->setItem(row, 4, new QTableWidgetItem(eq->available() ? "Available" : "Reserved"));

        // clerk specific reserved by column
        if (isClerk) {
            ui->equipmentTable->setItem(row, 5, new QTableWidgetItem(QString::fromStdString(eq->getReservedBy())));
        }

        QPushButton* viewButton = new QPushButton("View Details");
        ui->equipmentTable->setCellWidget(row, 6, viewButton);

        // connect view details button to equipmentdetails window
        connect(viewButton, &QPushButton::clicked, this, [this, eq]() {
            EquipmentDetails* detailsWindow = new EquipmentDetails(eq, currentRole, currentUser, this);
            connect(detailsWindow, &EquipmentDetails::reservationMade, this, &MainWindow::onReservationMade);
            detailsWindow->setAttribute(Qt::WA_DeleteOnClose);
            detailsWindow->show();
        });
    }
}

// search for equipment
void MainWindow::on_searchButton_clicked() {
    QString query = ui->searchInput->text();
    std::vector<Equipment*> filteredList;

    for (const auto& eq : manager->getInventory()) {
        if (QString::fromStdString(eq->getName()).contains(query, Qt::CaseInsensitive) ||
            QString::fromStdString(eq->getType()).contains(query, Qt::CaseInsensitive)) {
            filteredList.push_back(eq);
        }
    }

    displayInventory(filteredList);
    ui->searchInput->clear();
    ui->backButton->setVisible(true);
    navigationHistory.push(manager->getInventory());
}

void MainWindow::populateCategoryComboBox() {
    std::set<std::string> categories;
    ui->categoryComboBox->addItem("All");

    for (const auto& eq : manager->getInventory()) {
        categories.insert(eq->getType());
    }

    for (const auto& category : categories) {
        ui->categoryComboBox->addItem(QString::fromStdString(category));
    }

    // add reserved/available filter options only for clerks
    if (currentRole == "Clerk") {
        ui->categoryComboBox->addItem("Reserved");
        ui->categoryComboBox->addItem("Available");
    }
}

// filter equipment by category
void MainWindow::on_categoryComboBox_currentIndexChanged(int index) {
    QString category = ui->categoryComboBox->itemText(index);
    std::vector<Equipment*> filteredList;

    if (category == "All") {
        filteredList = manager->getInventory();
    } else if (category == "Reserved") {
        for (auto eq : manager->getInventory()) {
            if (!eq->available()) {
                filteredList.push_back(eq);
            }
        }
    } else if (category == "Available") {
        for (auto eq : manager->getInventory()) {
            if (eq->available()) {
                filteredList.push_back(eq);
            }
        }
    } else {
        for (auto eq : manager->getInventory()) {
            if (QString::fromStdString(eq->getType()) == category.toStdString()) {
                filteredList.push_back(eq);
            }
        }
    }

    displayInventory(filteredList);
    ui->backButton->setVisible(true);
    navigationHistory.push(manager->getInventory());
}

// go back to the previous state
void MainWindow::on_backButton_clicked() {
    if (!navigationHistory.empty()) {
        std::vector<Equipment*> previousState = navigationHistory.top();
        navigationHistory.pop();

        displayInventory(previousState);
        if (navigationHistory.empty()) {
            ui->backButton->setVisible(false);
        }
    }
}

void MainWindow::onReservationMade(Equipment* equipment) {
    // update status in the table
    for (int row = 0; row < ui->equipmentTable->rowCount(); ++row) {
        if (ui->equipmentTable->item(row, 0)->text().toStdString() == equipment->getID()) {
            ui->equipmentTable->item(row, 4)->setText("Reserved");
            if (currentRole == "Clerk") {
                ui->equipmentTable->item(row, 5)->setText(QString::fromStdString(equipment->getReservedBy()));
            }
            break;
        }
    }
}

void MainWindow::on_accountButton_clicked() {
    AccountWindow* accountWindow = new AccountWindow(currentUser, *manager, this);
    accountWindow->setAttribute(Qt::WA_DeleteOnClose);
    accountWindow->show();
}

// clerk-only methods
// add equipment
void MainWindow::on_addButton_clicked() {
    QDialog addDialog(this);
    addDialog.setWindowTitle("Add Equipment");

    QFormLayout* formLayout = new QFormLayout(&addDialog);
    QLineEdit* idEdit = new QLineEdit();
    QLineEdit* nameEdit = new QLineEdit();
    QDoubleSpinBox* priceEdit = new QDoubleSpinBox();
    QComboBox* typeComboBox = new QComboBox();
    typeComboBox->addItems({"Camera", "Lighting", "Audio"});

    priceEdit->setRange(0.0, 10000.0);

    formLayout->addRow("ID:", idEdit);
    formLayout->addRow("Name:", nameEdit);
    formLayout->addRow("Price:", priceEdit);
    formLayout->addRow("Type:", typeComboBox);

    QDialogButtonBox* buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
    formLayout->addWidget(buttonBox);

    connect(buttonBox, &QDialogButtonBox::accepted, &addDialog, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, &addDialog, &QDialog::reject);

    if (addDialog.exec() == QDialog::Accepted) {
        QString id = idEdit->text();
        QString name = nameEdit->text();
        double price = priceEdit->value();
        QString type = typeComboBox->currentText();

        if (id.isEmpty() || name.isEmpty()) {
            QMessageBox::warning(this, "Error", "ID and Name cannot be empty.");
            return;
        }

        Equipment* newEquipment = nullptr;
        if (type == "Camera") {
            newEquipment = new Camera(id.toStdString(), name.toStdString(), price, "Resolution");
        } else if (type == "Lighting") {
            newEquipment = new Lighting(id.toStdString(), name.toStdString(), price, "Light Type");
        } else if (type == "Audio") {
            newEquipment = new Audio(id.toStdString(), name.toStdString(), price, "Input", "Output");
        }

        if (newEquipment) {
            manager->addEquipment(newEquipment);
            displayInventory(manager->getInventory());
            QMessageBox::information(this, "Success", "Equipment added successfully.");
        }
    }
}

// edit exising euqipmentusing equipment id
void MainWindow::on_editButton_clicked() {
    int selectedRow = ui->equipmentTable->currentRow();
    if (selectedRow < 0) {
        QMessageBox::warning(this, "Edit Equipment", "Please select an item to edit.");
        return;
    }

    QString itemID = ui->equipmentTable->item(selectedRow, 0)->text().trimmed();

    qDebug() << "Selected Item ID:" << itemID;

    Equipment* equipmentToEdit = nullptr;
    for (const auto& eq : manager->getInventory()) {
        qDebug() << "Checking Inventory Equipment ID:" << QString::fromStdString(eq->getID());
        if (QString::fromStdString(eq->getID()) == itemID) {
            equipmentToEdit = eq;
            break;
        }
    }

    if (!equipmentToEdit) {
        QMessageBox::warning(this, "Error", "Selected equipment not found.");
        return;
    }

    QDialog editDialog(this);
    editDialog.setWindowTitle("Edit Equipment");

    QFormLayout* formLayout = new QFormLayout(&editDialog);

    QLineEdit* nameEdit = new QLineEdit(QString::fromStdString(equipmentToEdit->getName()));
    QDoubleSpinBox* priceEdit = new QDoubleSpinBox();
    priceEdit->setRange(0.0, 10000.0);
    priceEdit->setValue(equipmentToEdit->getPrice());

    formLayout->addRow("Name:", nameEdit);
    formLayout->addRow("Price:", priceEdit);

    QDialogButtonBox* buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
    formLayout->addWidget(buttonBox);

    connect(buttonBox, &QDialogButtonBox::accepted, &editDialog, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, &editDialog, &QDialog::reject);

    if (editDialog.exec() == QDialog::Accepted) {
        equipmentToEdit->setName(nameEdit->text().toStdString());
        equipmentToEdit->setPrice(priceEdit->value());

        // refresh the equipment table to show chnages.
        displayInventory(manager->getInventory());
        QMessageBox::information(this, "Success", "Equipment updated successfully.");
    }
}

// remove equipment using equipment id
void MainWindow::on_removeButton_clicked() {
    int selectedRow = ui->equipmentTable->currentRow();
    if (selectedRow < 0) {
        QMessageBox::warning(this, "Remove Equipment", "Please select an item to remove.");
        return;
    }

    QString itemName = ui->equipmentTable->item(selectedRow, 0)->text();

    if (QMessageBox::question(this, "Confirm Removal", QString("Are you sure you want to remove '%1'?").arg(itemName)) == QMessageBox::Yes) {
        auto& inventory = manager->getInventory();
        auto it = std::remove_if(inventory.begin(), inventory.end(),
                                 [&itemName](Equipment* eq) {
                                     if (QString::fromStdString(eq->getName()) == itemName) {
                                         delete eq;
                                         return true;
                                     }
                                     return false;
                                 });

        inventory.erase(it, inventory.end());
        displayInventory(manager->getInventory());
        QMessageBox::information(this, "Success", "Equipment removed successfully.");
    }
}

// log an equipment return
void MainWindow::on_logReturnButton_clicked() {
    int selectedRow = ui->equipmentTable->currentRow();
    if (selectedRow < 0) {
        QMessageBox::warning(this, "Log Return", "Please select an item to return.");
        return;
    }

    QString itemID = ui->equipmentTable->item(selectedRow, 0)->text();

    Equipment* equipmentToLog = nullptr;
    for (const auto& eq : manager->getInventory()) {
        if (QString::fromStdString(eq->getID()) == itemID) {
            equipmentToLog = eq;
            break;
        }
    }

    if (!equipmentToLog) {
        QMessageBox::warning(this, "Error", "Selected equipment not found.");
        return;
    }

    if (equipmentToLog->available()) {
        QMessageBox::information(this, "Log Return", "This equipment is available.");
        return;
    }

    // mark the equipment as returned
    QString reservedBy = QString::fromStdString(equipmentToLog->getReservedBy());
    equipmentToLog->makeAvailable();
    equipmentToLog->setReservedBy("");

    // notify the user who reserved the equipment
    if (!reservedBy.isEmpty()) {
        QString notificationMessage = QString(
                                          "The equipment '%1' has been returned. Thank you for using our service!")
                                          .arg(QString::fromStdString(equipmentToLog->getName()));

        NotificationManager::getInstance()->addNotification(notificationMessage.toStdString());
    }

    // refresh inventory and notify the clerk
    displayInventory(manager->getInventory());
    QMessageBox::information(this, "Success", "Equipment returned successfully.");
}

// log damage on any equipment in the system
void MainWindow::on_logDamageButton_clicked() {
    int selectedRow = ui->equipmentTable->currentRow();
    if (selectedRow < 0) {
        QMessageBox::warning(this, "Log Damage", "Please select an item to log damage.");
        return;
    }

    QString itemID = ui->equipmentTable->item(selectedRow, 0)->text();

    Equipment* equipmentToLog = nullptr;
    for (const auto& eq : manager->getInventory()) {
        if (QString::fromStdString(eq->getID()) == itemID) {
            equipmentToLog = eq;
            break;
        }
    }

    if (!equipmentToLog) {
        QMessageBox::warning(this, "Error", "Selected equipment not found.");
        return;
    }

    QDialog damageDialog(this);
    damageDialog.setWindowTitle("Log Damage");

    QFormLayout* formLayout = new QFormLayout(&damageDialog);
    QTextEdit* damageDescription = new QTextEdit();
    formLayout->addRow("Damage Description:", damageDescription);

    QDialogButtonBox* buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
    formLayout->addWidget(buttonBox);

    connect(buttonBox, &QDialogButtonBox::accepted, &damageDialog, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, &damageDialog, &QDialog::reject);

    if (damageDialog.exec() == QDialog::Accepted) {
        QString damageReport = damageDescription->toPlainText();
        if (damageReport.isEmpty()) {
            QMessageBox::warning(this, "Error", "Damage description cannot be empty.");
            return;
        }

        // update the equipment's damage description
        equipmentToLog->setDamageDescription(damageReport.toStdString());

        // save the updated inventory to the CSV file
        if (!manager->saveInventoryToCSV(QDir::currentPath().toStdString() + "/inventory.csv")) {
            QMessageBox::warning(this, "Error", "Failed to save damage to the inventory file.");
            return;
        }

        QMessageBox::information(this, "Success", "Damage logged successfully.");

        // refresh the equipment table to reflect the changes
        displayInventory(manager->getInventory());
    }
}

// check when an item is scheduled to be picked up
void MainWindow::on_checkPickupButton_clicked() {
    int selectedRow = ui->equipmentTable->currentRow();
    if (selectedRow < 0) {
        QMessageBox::warning(this, "Check Pickup", "Please select an equipment item to check pickup.");
        return;
    }

    QString itemID = ui->equipmentTable->item(selectedRow, 0)->text();

    Equipment* equipmentToCheck = nullptr;
    for (const auto& eq : manager->getInventory()) {
        if (QString::fromStdString(eq->getID()) == itemID) {
            equipmentToCheck = eq;
            break;
        }
    }

    if (!equipmentToCheck) {
        QMessageBox::warning(this, "Error", "Selected equipment not found.");
        return;
    }

    if (equipmentToCheck->available()) {
        QMessageBox::information(this, "Check Pickup", "The equipment is available.");
    } else {
        QString reservedBy = QString::fromStdString(equipmentToCheck->getReservedBy());
        QMessageBox::information(this, "Pickup Info",
                                 QString("Equipment: %1\nReserved by: %2\nStatus: Reserved").arg(itemID, reservedBy));
    }
}

void MainWindow::resetUI() {
    while (!navigationHistory.empty()) {
        navigationHistory.pop();
    }

    displayInventory(manager->getInventory());

    ui->backButton->setVisible(false);
}

#include <QInputDialog>
#include <QDateEdit>
#include <QFormLayout>
#include <QMessageBox>
#include <QCalendarWidget>
#include <QTimeEdit>
#include <QComboBox>
#include <QPushButton>

#include "equipmentdetails.h"
#include "ui_equipmentdetails.h"
#include "notification_manager.h"
#include "dialogbuilder.cpp"

int EquipmentDetails::reservationCounter = 1000;

EquipmentDetails::EquipmentDetails(Equipment* equipment, const QString& currentRole, const QString& currentUser, QWidget* parent)
    : QMainWindow(parent), ui(new Ui::EquipmentDetails), equipment(equipment), currentRole(currentRole), currentUser(currentUser) {
    ui->setupUi(this);

    setWindowTitle(QString::fromStdString(equipment->getName()));

    // display equipment details
    ui->nameLabel->setText(QString("Name: %1").arg(QString::fromStdString(equipment->getName())));
    ui->typeLabel->setText(QString("Type: %1").arg(QString::fromStdString(equipment->getType())));
    ui->priceLabel->setText(QString("Price: $%1").arg(equipment->getPrice()));
    ui->statusLabel->setText(QString("Status: %1").arg(equipment->available() ? "Available" : "Reserved"));

    // if user is clerk display the reserved by and damage fields
    if (currentRole == "Clerk") {
        QString reservedBy = equipment->available() ? "None" : QString::fromStdString(equipment->getReservedBy());
        ui->reservedByLabel->setText(QString("Reserved By: %1").arg(reservedBy));

        QString damageText = QString::fromStdString(equipment->getDamageDescription());
        ui->damageLabel->setText(QString("Damage: %1").arg(damageText.isEmpty() ? "No damage reported." : damageText));
    } else {
        // hide labels to non clerks
        ui->reservedByLabel->hide();
        ui->damageLabel->hide();
    }

    connect(ui->requestButton, &QPushButton::clicked, this, &EquipmentDetails::handleReservationRequest);
    connect(ui->closeButton, &QPushButton::clicked, this, &EquipmentDetails::close);

    resize(300, 300);
}

EquipmentDetails::~EquipmentDetails() {
    delete ui;
}

// handle reservation process
void EquipmentDetails::handleReservationRequest() {
    QDate startDate = QDate::currentDate();
    QDate endDate = QDate::currentDate().addDays(1);
    QString pickupTime;

    while (true) {
        QDialog* formDialog = DialogBuilder::createReservationDialog(this, startDate, endDate, pickupTime);

        if (formDialog->exec() == QDialog::Accepted) {
            // retrieve user enters reservation details
            startDate = DialogBuilder::getStartDate(formDialog);
            endDate = DialogBuilder::getEndDate(formDialog);
            pickupTime = DialogBuilder::getPickupTime(formDialog);

            delete formDialog;

            // validate selected dates
            if (startDate >= endDate) {
                QMessageBox::warning(this, "Invalid Dates", "End date must be after start date.");
                // prompt user again
                continue;
            }

            // confirm reservation with user
            if (!confirmReservation(startDate, endDate, pickupTime)) {
                // if usr cancels
                return;
            }

            // check equipment availability and confirm reservation
            if (equipment->available()) {
                completeReservation(startDate, endDate, pickupTime);
                // successful resrvation
                return;
            // cross-check reservation and equipment availablity
            } else {
                qDebug() << "Equipment is not available. Reserved By:" << QString::fromStdString(equipment->getReservedBy());
                QMessageBox::warning(this, "Reservation Unavailable", "The equipment is not available during the requested period.");
                return;
            }
        } else {
            delete formDialog;
            return;
        }
    }
}

// dialog to confirm reservation details
bool EquipmentDetails::confirmReservation(const QDate& startDate, const QDate& endDate, const QString& pickupTime) {
    QString confirmationMessage = QString(
                                      "<b style='font-size: 14px;'>Please confirm your reservation:</b><br><br>"
                                      "Equipment: %1<br>"
                                      "Start Date: %2<br>"
                                      "End Date: %3<br>"
                                      "Pickup Time: %4<br>")
                                      .arg(QString::fromStdString(equipment->getName()))
                                      .arg(startDate.toString("yyyy-MM-dd"))
                                      .arg(endDate.toString("yyyy-MM-dd"))
                                      .arg(pickupTime);

    QMessageBox::StandardButton reply = QMessageBox::question(
        this, "Confirm Reservation", confirmationMessage, QMessageBox::Yes | QMessageBox::No);

    return reply == QMessageBox::Yes;
}

// complete the reservation process
void EquipmentDetails::completeReservation(const QDate& startDate, const QDate& endDate, const QString& pickupTime) {
    // mark the equipment as reserved
    equipment->reserveEquipment(currentUser.toStdString());
    ui->statusLabel->setText("Status: Reserved");
    ui->reservedByLabel->setText(QString("Reserved By: %1").arg(currentUser));

    // add notification about the reservation
    NotificationManager::getInstance()->addNotification(
        "Reservation confirmed for: " + equipment->getName() +
        ". \n\nPickup scheduled for: " + startDate.toString("yyyy-MM-dd").toStdString() +
        " at " + pickupTime.toStdString() + ".\n");

    // signal to indicate a reservatin was made
    emit reservationMade(equipment);

    QMessageBox::information(this, "Reservation Successful", "Your reservation has been confirmed.");
}


#include <QDialog>
#include <QFormLayout>
#include <QDateEdit>
#include <QComboBox>
#include <QTime>
#include <QDialogButtonBox>
#include <QObject>
#include <QVariant>

// create and manage reservation dialog
class DialogBuilder {
public:
    // create reservation dialog with dates and pick up times
    static QDialog* createReservationDialog(QWidget* parent, QDate& startDate, QDate& endDate, QString& pickupTime) {
        QDialog* dialog = new QDialog(parent);
        dialog->setWindowTitle("Reservation Request");

        QFormLayout* formLayout = new QFormLayout(dialog);

        // pop up calendars for dates
        QDateEdit* startDateEdit = new QDateEdit(startDate);
        QDateEdit* endDateEdit = new QDateEdit(endDate);
        startDateEdit->setCalendarPopup(true);
        endDateEdit->setCalendarPopup(true);

        formLayout->addRow("Start Date:", startDateEdit);
        formLayout->addRow("End Date:", endDateEdit);

        // drp down for pick up time
        QComboBox* pickupTimeDropdown = new QComboBox();
        for (int hour = 9; hour <= 16; ++hour) {
            for (int minute = 0; minute < 60; minute += 15) {
                QTime time(hour, minute);
                pickupTimeDropdown->addItem(time.toString("hh:mm AP"));
            }
        }
        pickupTimeDropdown->setCurrentText(pickupTime);
        formLayout->addRow("Pickup Time:", pickupTimeDropdown);

        QDialogButtonBox* buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
        formLayout->addWidget(buttonBox);

        QObject::connect(buttonBox, &QDialogButtonBox::accepted, dialog, &QDialog::accept);
        QObject::connect(buttonBox, &QDialogButtonBox::rejected, dialog, &QDialog::reject);

        dialog->setProperty("startDateEdit", QVariant::fromValue(startDateEdit));
        dialog->setProperty("endDateEdit", QVariant::fromValue(endDateEdit));
        dialog->setProperty("pickupTimeDropdown", QVariant::fromValue(pickupTimeDropdown));

        return dialog;
    }

    // get the start date from the dialog
    static QDate getStartDate(QDialog* dialog) {
        return qobject_cast<QDateEdit*>(dialog->property("startDateEdit").value<QObject*>())->date();
    }

    // get the end date from the dialog
    static QDate getEndDate(QDialog* dialog) {
        return qobject_cast<QDateEdit*>(dialog->property("endDateEdit").value<QObject*>())->date();
    }

    // get the selected pick up time
    static QString getPickupTime(QDialog* dialog) {
        return qobject_cast<QComboBox*>(dialog->property("pickupTimeDropdown").value<QObject*>())->currentText();
    }
};

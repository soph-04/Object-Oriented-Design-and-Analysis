#ifndef SUBJECT_H
#define SUBJECT_H

#include <vector>
#include <string>
#include <algorithm>

#include "observer.h"
#include "qdebug.h"
#include "qlogging.h"

class Subject {
protected:
    std::vector<Observer*> observers;

public:
    virtual ~Subject() {}

    void attach(Observer* observer) {
        observers.push_back(observer);
        qDebug() << "Observer attached. Total observers:" << observers.size();
    }

    void notify(const std::string& message) {
        for (Observer* observer : observers) {
            try {
                if (observer) {
                    observer->update(message);
                } else {
                    qWarning() << "Null observer encountered during notification.";
                }
            } catch (const std::exception& ex) {
                qWarning() << "Exception during notification:" << ex.what();
            }
        }
    }


    void detach(Observer* observer) {
        observers.erase(std::remove(observers.begin(), observers.end(), observer), observers.end());
    }
};

#endif // SUBJECT_H

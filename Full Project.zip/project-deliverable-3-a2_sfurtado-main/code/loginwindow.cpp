#include <QDir>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QDebug>

#include "loginwindow.h"
#include "mainwindow.h"
#include "ui_loginwindow.h"

LoginWindow::LoginWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::LoginWindow) {
    ui->setupUi(this);

    loadUsers();

    ui->errorLabel->clear();
}

LoginWindow::~LoginWindow() {
    delete ui;
}

// load users from csv
void LoginWindow::loadUsers() {
    QString filePath = QDir::currentPath() + "/users.csv";

    QFile file(filePath);
    if (!file.exists()) {
        // make default file if one doesnt exist
        createDefaultUsersFile();
    }

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Unable to load users file.");
        return;
    }

    QTextStream in(&file);
    bool isFirstLine = true;

    // read each line of the file
    while (!in.atEnd()) {
        QString line = in.readLine();
        if (line.trimmed().isEmpty()) {
            continue;
        }

        if (isFirstLine) {
            isFirstLine = false;
            continue;
        }

        // separate each line into individual fields
        QStringList fields = line.split(",");
        if (fields.size() != 3) {
            qDebug() << "Invalid line detected: " << line;
            continue;
        }

        QString username = fields[0].trimmed();
        QString password = fields[1].trimmed();
        QString role = fields[2].trimmed();

        users[username] = {username, password, role};

        qDebug() << "Loaded user:" << username << ", password:" << password << ", role:" << role;
    }

    file.close();
}

// add loaded user to the user map and save to csv
void LoginWindow::addUser(const QString& username, const QString& password, const QString& role) {
    if (users.contains(username)) {
        QMessageBox::warning(this, "Error", "User already exists.");
        return;
    }

    users[username] = {username, password, role};
    saveUsers();
}

// save all users from map to csv
void LoginWindow::saveUsers() {
    QString filePath = QDir::currentPath() + "/users.csv";

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Unable to save users file.");
        return;
    }

    QTextStream out(&file);

    for (auto it = users.begin(); it != users.end(); ++it) {
        out << it.key() << "," << it.value().password << "," << it.value().role << "\n";
    }

    file.close();
}

// when log in button is clicked, if the user exists, check their role and open the appropriate main window
void LoginWindow::on_loginButton_clicked() {
    QString username = ui->usernameInput->text();
    QString password = ui->passwordInput->text();

    if (users.contains(username)) {
        const UserInfo& userInfo = users[username];

        if (userInfo.password == password) {
            QString role = userInfo.role;

            qDebug() << "Login successful for user:" << username << "with role:" << role;

            MainWindow* mainWindow = new MainWindow(username, role);
            mainWindow->show();

            this->close();
        } else {
            QMessageBox::warning(this, "Error", "Invalid password.");
        }
    } else {
        QMessageBox::warning(this, "Error", "User not found.");
    }
}


// create a csv of default users if one doesnt exist
void LoginWindow::createDefaultUsersFile() {
    QString filePath = QDir::currentPath() + ":/resources/users";

    QFile file(filePath);
    if (file.exists()) {
        return;
    }

    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);

        out << "sfurtad7,cs3307,Member\n";
        out << "ta,sfurtad7,Clerk\n";

        file.close();
    }
}

#include <gtest/gtest.h>
#include <gmock/gmock.h>

#include "mainwindow.h"
#include "equipment.h"
#include "notification_manager.h"
#include "observer.h"
#include "accountwindow.h"
#include "inventory_manager.h"

// Mock classes

// Mock for equipment
class MockEquipment : public Equipment {
public:
    MockEquipment() : Equipment("MockID", "MockName", "MockType", 0.0) {}

    MOCK_METHOD(std::string, getID, (), (const, override));
    MOCK_METHOD(std::string, getName, (), (const, override));
    MOCK_METHOD(std::string, getType, (), (const, override));
    MOCK_METHOD(double, getPrice, (), (const, override));
    MOCK_METHOD(bool, available, (), (const, override));
    MOCK_METHOD(std::string, getReservedBy, (), (const, override));
    MOCK_METHOD(void, reserveEquipment, (const std::string&), (override));
    MOCK_METHOD(void, makeAvailable, (), (override));
    MOCK_METHOD(void, setReservedBy, (const std::string&), (override));

    void displayDetails() const override {}  // Stub to avoid abstract class issue
};

// Mock for inventory_manager
class MockInventoryManager : public InventoryManager {
public:
    MOCK_METHOD(void, addEquipment, (Equipment*), (override));
    MOCK_METHOD(std::vector<Equipment*>&, getInventory, (), (override));
    MOCK_METHOD(void, removeEquipment, (const std::string&), (override));
    MOCK_METHOD(bool, loadInventoryFromCSV, (const std::string&), (override));
    MOCK_METHOD(bool, saveInventoryToCSV, (const std::string&), (override));
};

// Mock for observer
class MockObserver : public Observer {
public:
    MOCK_METHOD(void, update, (const std::string&), (override));
};

// Mock for mainwindow
class MockMainWindow : public MainWindow {
public:
    MockMainWindow() : MainWindow("TestUser", "Clerk", nullptr) {}
};

// mainwindow tests

TEST(MainWindowTest, DisplayInventoryWithoutInjection) {
    MockInventoryManager mockManager;
    MockEquipment equipment1, equipment2;

    EXPECT_CALL(equipment1, getID()).WillRepeatedly(::testing::Return("E001"));
    EXPECT_CALL(equipment1, getName()).WillRepeatedly(::testing::Return("Camera A"));
    EXPECT_CALL(equipment1, getType()).WillRepeatedly(::testing::Return("Camera"));
    EXPECT_CALL(equipment1, getPrice()).WillRepeatedly(::testing::Return(50.0));
    EXPECT_CALL(equipment1, available()).WillRepeatedly(::testing::Return(true));

    EXPECT_CALL(equipment2, getID()).WillRepeatedly(::testing::Return("E002"));
    EXPECT_CALL(equipment2, getName()).WillRepeatedly(::testing::Return("Lighting Kit"));
    EXPECT_CALL(equipment2, getType()).WillRepeatedly(::testing::Return("Lighting"));
    EXPECT_CALL(equipment2, getPrice()).WillRepeatedly(::testing::Return(100.0));
    EXPECT_CALL(equipment2, available()).WillRepeatedly(::testing::Return(false));

    std::vector<Equipment*> inventory = {&equipment1, &equipment2};
    EXPECT_CALL(mockManager, getInventory()).WillOnce(::testing::ReturnRef(inventory));

    std::vector<Equipment*> mockInventory = mockManager.getInventory();
    EXPECT_EQ(static_cast<int>(mockInventory.size()), 2);
}

// notification_manager tests

TEST(NotificationManagerTest, AddNotification) {
    NotificationManager* manager = NotificationManager::getInstance();

    manager->addNotification("Test notification 1");

    const auto& notifications = manager->getNotifications();
    ASSERT_EQ(static_cast<int>(notifications.size()), 1);
    EXPECT_EQ(notifications[0], "Test notification 1");
}

TEST(NotificationManagerTest, GetNotifications) {
    NotificationManager* manager = NotificationManager::getInstance();

    manager->addNotification("Test notification 2");
    manager->addNotification("Test notification 3");

    const auto& notifications = manager->getNotifications();
    ASSERT_EQ(static_cast<int>(notifications.size()), 3);  // Including previous tests
    EXPECT_EQ(notifications[1], "Test notification 2");
    EXPECT_EQ(notifications[2], "Test notification 3");
}

TEST(NotificationManagerTest, ObserverNotification) {
    NotificationManager* manager = NotificationManager::getInstance();
    MockObserver mockObserver;

    manager->attach(&mockObserver);
    EXPECT_CALL(mockObserver, update("Observer notification test"));

    manager->addNotification("Observer notification test");
    manager->detach(&mockObserver);
}

// accountwindow tests
TEST(AccountWindowTest, NotificationsDisplay) {
    NotificationManager::getInstance()->clearNotifications();

    InventoryManager* mockManager = InventoryManager::getInstance();
    MainWindow mockMainWindow("TestUser", "Member");
    AccountWindow accountWindow("TestUser", *mockManager, &mockMainWindow);

    NotificationManager::getInstance()->addNotification("Test Notification");

    accountWindow.triggerLoadNotifications();

    QListWidget* notificationsList = accountWindow.getNotificationsList();
    ASSERT_NE(notificationsList, nullptr);
    EXPECT_EQ(notificationsList->count(), 1);
    EXPECT_EQ(notificationsList->item(0)->text().toStdString(), "Test Notification");
}

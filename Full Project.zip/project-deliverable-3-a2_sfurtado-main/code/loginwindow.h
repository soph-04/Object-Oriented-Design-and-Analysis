#ifndef LOGINWINDOW_H
#define LOGINWINDOW_H

#include <QMainWindow>
#include <QMap>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui {
class LoginWindow;
}

// struct to store user details
struct UserInfo {
    QString name;
    QString password;
    QString role;
};

class LoginWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit LoginWindow(QWidget *parent = nullptr);
    ~LoginWindow();

    bool validateUserPassword(const QString& username, const QString& currentPassword) const;
    void updateUserPassword(const QString& username, const QString& newPassword);

private slots:
    void on_loginButton_clicked();

private:
    Ui::LoginWindow *ui;

    QMap<QString, UserInfo> users;
    // save an load users from csv
    void loadUsers();
    void saveUsers();
    void addUser(const QString& username, const QString& password, const QString& role);
    void createDefaultUsersFile();
};

#endif // LOGINWINDOW_H

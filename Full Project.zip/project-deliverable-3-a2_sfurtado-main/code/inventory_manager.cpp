#include <fstream>
#include <sstream>
#include <algorithm>
#include <QMessageBox>
#include <QDebug>

#include "inventory_manager.h"

InventoryManager* InventoryManager::instance = nullptr;
std::mutex InventoryManager::instanceMutex;

// singleton pattern --> get the single insatnc of inventoryamanger
InventoryManager* InventoryManager::getInstance() {
    // thread-safe Singleton implementation
    std::lock_guard<std::mutex> lock(instanceMutex);
    if (!instance) {
        instance = new InventoryManager();
    }
    return instance;
}

// add new equipment to the inventory
void InventoryManager::addEquipment(Equipment* equipment) {
    qDebug() << "Adding equipment to inventory:" << QString::fromStdString(equipment->getName());
    equipmentList.push_back(equipment);
    qDebug() << "Current inventory size:" << equipmentList.size();
}

// reference to the equipment list
std::vector<Equipment*>& InventoryManager::getInventory() {
    return equipmentList;
}

// remove equipment by its id
void InventoryManager::removeEquipment(const std::string& id) {
    auto it = std::remove_if(equipmentList.begin(), equipmentList.end(),
                             [&id](Equipment* eq) {
                                 if (eq->getID() == id) {
                                     delete eq;
                                     return true;
                                 }
                                 return false;
                             });
    equipmentList.erase(it, equipmentList.end());
}

// trim any leading or trailing whitespace from string
std::string InventoryManager::trim(const std::string& str) {
    size_t first = str.find_first_not_of(" \t");
    size_t last = str.find_last_not_of(" \t");
    return (first == std::string::npos || last == std::string::npos) ? "" : str.substr(first, last - first + 1);
}

// load inventory from csv
bool InventoryManager::loadInventoryFromCSV(const std::string& filePath) {
    std::ifstream file(filePath);
    if (!file.is_open()) {
        qDebug() << "Failed to open inventory file:" << QString::fromStdString(filePath);
        return false;
    }

    qDebug() << "Opened file:" << QString::fromStdString(filePath);

    std::string line;
    int lineNumber = 0;

    // read each line of the csv
    while (std::getline(file, line)) {
        lineNumber++;
        qDebug() << "Processing line:" << QString::fromStdString(line);

        if (line.empty()) {
            qDebug() << "Skipping empty line.";
            continue;
        }

        if (lineNumber == 1 && line.find("ID,Name,Price,Type,ReservedBy") != std::string::npos) {
            qDebug() << "Skipping header line.";
            continue;
        }

        // parse csv line into indivdual fields
        std::istringstream stream(line);
        std::string id, name, priceStr, type, reservedBy;

        if (!std::getline(stream, id, ',')) continue;
        if (!std::getline(stream, name, ',')) continue;
        if (!std::getline(stream, priceStr, ',')) continue;
        if (!std::getline(stream, type, ',')) continue;
        std::getline(stream, reservedBy); // Optional field

        id = trim(id);
        name = trim(name);
        priceStr = trim(priceStr);
        type = trim(type);
        reservedBy = trim(reservedBy);

        double price = std::stod(priceStr);

        // creat equipment object based on its type
        Equipment* equipment = nullptr;
        if (type == "Camera") {
            equipment = new Camera(id, name, price, "Default Resolution");
        } else if (type == "Lighting") {
            equipment = new Lighting(id, name, price, "Default Light Type");
        } else if (type == "Audio") {
            equipment = new Audio(id, name, price, "Default Input", "Default Output");
        }

        if (equipment) {
            if (!reservedBy.empty() && reservedBy != ",") {
                equipment->reserveEquipment(reservedBy); // mark as reserved if valid
            } else {
                equipment->makeAvailable(); // explicitly mark the equipment as available
            }
            addEquipment(equipment);
        }
    }
    file.close();
    return true;
}

// save current inventory to csv
bool InventoryManager::saveInventoryToCSV(const std::string& filePath) {
    std::ofstream file(filePath);
    if (!file.is_open()) {
        QMessageBox::warning(nullptr, "Error", "Failed to open inventory file for saving.");
        return false;
    }

    // write each equipments details
    file << "ID,Name,Price,Type,ReservedBy\n";
    for (const auto& eq : equipmentList) {
        file << eq->getID() << "," << eq->getName() << "," << eq->getPrice() << ","
             << eq->getType() << "," << eq->getReservedBy() << "\n";
    }
    file.close();
    return true;
}

#include <QApplication>
#include <QFile>

#include "loginwindow.h"
// #include <gtest/gtest.h>

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    LoginWindow loginWindow;
    loginWindow.show();

    return app.exec();

    /* ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();*/
}

# Film Equipment Management System

This system is user to manage a wide range of equipment such as cameras, microphones and lighting gear for video production rental stores. With this system, stores can efficiently manage inventory, and simplify the in-store rental process.  

Some key features include user authentications, inventory management add, edit, remove), equipment reservation and return functionality and notifications for reservations, cancellations, pick ups and returns.

**The most updated version of the sysem can be found on the main branch.**

## Compilation Instructions
In this section I will provide step-by-step instuctions to run my project. 

1. Open ProjectTemplate.pro in QT
2. Under the Build tab, select Run Qmake 
3. Under the same tab, select Rebuild
4. Then, on the bottom left of the window, select the green play button. 
5. The code should then run, opening a new login window. 

## How to use the system
1. Enter the user credentials 
    - To login as a member, use the username: "sfurtad7" and the password: "cs3307"
    - To login as a clerk, use the username: "ta" and the password: "sfurtad7"
2. Once logged in, you can view all the equipment, there are features to sort by equipment type, and search for any equipment. 
3. To view and equipment item's details, select the view details button in the description column for that item. 
4. In the new window you can reserve said equipment item by clicking the reserve button. 
5. You will be prompted to selected dates to reserve the equipment for and select a time to pick up the item on the first day of the reservation
6. Once you enter all the details you will be prompted to confirm the details. 
7. After you click confirm, the equipment is succesfully reserved by you. You can confirm the reservation by going to your Account window and selecting the orders tab. 
8. This tab will show you all your active requests and give you the option to cancel them. 
9. The notifications tab in this window shows all the notificationsw for your account. You receive notifications when you reserve equipment, cancel reservations and when your return is proccesed. 
10. In the profile tab, you can view profile details and log out. 
11. After logging out, log back in as a clerk. You will be taken to a clerk specific main window, with more features. 
12. You can view all the equipment and who it's reserved by. You can also add, remove and edit equipment that will be reflected to all users in the session. 
13. Clerks can view equipment pickups, to make sure their ready, log damages which will appear in the items equipment details pop up (reached by click the items view details button), and log equipment returns which automatically notifies the user. 
14. All buttons and features are fully functional and should reflect to all users in a single session. 
15. Once a session is closed, all windows are reset for demonstration purposes. In explanding the systems, I would like to implement logic to save any data changed across all sessions. 

## Dependencies
QT 6: GUI framework
Google Test/Mock: Unit testing framework

#ifndef ACCOUNTWINDOW_H
#define ACCOUNTWINDOW_H

#include <QMainWindow>
#include <QVBoxLayout>

#include "inventory_manager.h"
#include "observer.h"
#include "qlistwidget.h"

class MainWindow;

namespace Ui {
class AccountWindow;
}
// this class manages the user account window where users can view and manage notifcations, reservations, account details.
class AccountWindow : public QMainWindow, public Observer {
    Q_OBJECT

public:
    explicit AccountWindow(const QString& username, InventoryManager& manager, MainWindow* mainWindow, QWidget* parent = nullptr);

    // Overrides the update method from the Observer interface
    void update(const std::string& message) override;

    // Expose protected methods for testing
    void triggerLoadNotifications();
    QListWidget* getNotificationsList() const;

    ~AccountWindow();

private slots:
    void loadReservations();
    void loadNotifications();
    void cancelReservation(const QString& itemName);
    void on_closeButton_clicked();
    void setupProfileTab();
    void openChangePasswordDialog();

private:
    Ui::AccountWindow *ui;
    QString currentUser;
    InventoryManager& manager;
    QVBoxLayout* reservationLayout;
    MainWindow* mainWindow;
    void setupTabs();
    QListWidget* notificationsList;
};

#endif // ACCOUNTWINDOW_H

#include <QDebug>
#include <QMessageBox>
#include <QFileDialog>
#include <QFormLayout>
#include <QLineEdit>

#include "accountwindow.h"
#include "loginwindow.h"
#include "notification_manager.h"
#include "user.h"
#include "ui_accountwindow.h"
#include "mainwindow.h"

AccountWindow::AccountWindow(const QString& username, InventoryManager& manager, MainWindow* mainWindow, QWidget* parent)
    : QMainWindow(parent), ui(new Ui::AccountWindow), currentUser(username), manager(manager), mainWindow(mainWindow), notificationsList(nullptr) {
    ui->setupUi(this);

    setupTabs();

    // layout for reservations
    reservationLayout = new QVBoxLayout(ui->scrollAreaWidgetContents);
    loadReservations();

    ui->usernameLabel->setText("Current User: " + currentUser);

    connect(ui->tabWidget, &QTabWidget::currentChanged, this, [this](int index) {
        if (index == 1) {
            loadNotifications();
        }
    });

    // attach as an observer to NotificationManager
    NotificationManager::getInstance()->attach(this);
    qDebug() << "AccountWindow attached to NotificationManager.";
}

AccountWindow::~AccountWindow() {
    // detach before destruction
    NotificationManager::getInstance()->detach(this);
    delete ui;
    qDebug() << "AccountWindow destroyed.";
}

void AccountWindow::setupTabs()
{
    ui->tabWidget->setTabText(0, "Orders");
    ui->tabWidget->setTabText(1, "Notifications");
    ui->tabWidget->setTabText(2, "Profile");

    // notification tab
    QWidget* notificationsTab = ui->tabWidget->widget(1);
    QGridLayout* notificationsLayout = qobject_cast<QGridLayout*>(notificationsTab->layout());

    if (!notificationsLayout) {
        qDebug() << "Creating new layout for Notifications tab.";
        notificationsLayout = new QGridLayout(notificationsTab);
        notificationsTab->setLayout(notificationsLayout);
    }

    if (!notificationsList) {
        notificationsList = new QListWidget(this);
        notificationsLayout->addWidget(notificationsList, 0, 0);
        qDebug() << "notificationsList initialized and added to layout.";
    }

    // function for profile tab
    setupProfileTab();
}

void AccountWindow::setupProfileTab() {
    QWidget* profileTab = ui->tabWidget->widget(2);
    QVBoxLayout* profileLayout = new QVBoxLayout(profileTab);

    // set up profil pic logic
    QVBoxLayout* pictureLayout = new QVBoxLayout();
    QLabel* profilePicture = new QLabel();
    profilePicture->setPixmap(QPixmap(":/profile.jpg").scaled(120, 120, Qt::KeepAspectRatio));
    profilePicture->setAlignment(Qt::AlignCenter);
    pictureLayout->addWidget(profilePicture);

    QPushButton* uploadButton = new QPushButton("Upload Picture");
    connect(uploadButton, &QPushButton::clicked, this, [profilePicture]() {
        QString filePath = QFileDialog::getOpenFileName(nullptr, "Select Profile Picture", "", "Images (*.png *.jpg *.jpeg)");
        if (!filePath.isEmpty()) {
            profilePicture->setPixmap(QPixmap(filePath).scaled(120, 120, Qt::KeepAspectRatio));
        }
    });
    pictureLayout->addWidget(uploadButton);
    pictureLayout->setAlignment(Qt::AlignCenter);
    profileLayout->addLayout(pictureLayout);

    // set up user info
    QFormLayout* formLayout = new QFormLayout();
    QLineEdit* nameEdit = new QLineEdit(currentUser);
    formLayout->addRow("Name:", nameEdit);

    QLineEdit* emailEdit = new QLineEdit();
    emailEdit->setPlaceholderText("Enter your email");
    formLayout->addRow("Email:", emailEdit);

    QLineEdit* phoneEdit = new QLineEdit();
    phoneEdit->setPlaceholderText("Enter your phone number");
    formLayout->addRow("Phone Number:", phoneEdit);

    profileLayout->addLayout(formLayout);

    // change password logic
    // haven't succeeded in the change of password updating the csv logic
    QPushButton* changePasswordButton = new QPushButton("Change Password");
    changePasswordButton->setFixedWidth(150); // Set button width
    QHBoxLayout* passwordButtonLayout = new QHBoxLayout();
    passwordButtonLayout->addWidget(changePasswordButton);
    passwordButtonLayout->setAlignment(Qt::AlignCenter);
    profileLayout->addLayout(passwordButtonLayout);

    connect(changePasswordButton, &QPushButton::clicked, this, [this]() {
        openChangePasswordDialog();
    });

    // save an cancel buttons
    QHBoxLayout* buttonLayout = new QHBoxLayout();
    QPushButton* saveButton = new QPushButton("Save");
    QPushButton* cancelButton = new QPushButton("Cancel");
    QPushButton* logoutButton = new QPushButton("Log Out");
    buttonLayout->addWidget(saveButton);
    buttonLayout->addWidget(cancelButton);
    buttonLayout->addWidget(logoutButton);
    buttonLayout->setAlignment(Qt::AlignRight);

    connect(saveButton, &QPushButton::clicked, this, [this, nameEdit, emailEdit, phoneEdit]() {
        QMessageBox::information(this, "Profile Saved", "Your profile has been updated successfully!");
    });

    connect(cancelButton, &QPushButton::clicked, this, [nameEdit, emailEdit, phoneEdit, this]() {
        // reset fields to default values
        nameEdit->setText(currentUser);
        emailEdit->clear();
        phoneEdit->clear();
    });

    connect(logoutButton, &QPushButton::clicked, this, []() {
        QApplication::closeAllWindows();
        LoginWindow* loginWindow = new LoginWindow();
        loginWindow->show();
    });

    profileLayout->addLayout(buttonLayout);

    profileLayout->setSpacing(15);
    profileLayout->setContentsMargins(20, 20, 20, 20);
}

void AccountWindow::loadNotifications() {
    if (!notificationsList) {
        qWarning() << "notificationsList is null! Cannot load notifications.";
        return;
    }

    notificationsList->clear();
    const auto& notifications = NotificationManager::getInstance()->getNotifications();

    for (const std::string& notification : notifications) {
        notificationsList->addItem(QString::fromStdString(notification));
    }
    qDebug() << "Notifications loaded. Total:" << notifications.size();
}

void AccountWindow::update(const std::string& message) {
    qDebug() << "Received notification update:" << QString::fromStdString(message);
    if (notificationsList) {
        notificationsList->addItem(QString::fromStdString(message));
    } else {
        qWarning() << "notificationsList is null!";
    }
}

void AccountWindow::openChangePasswordDialog() {
    QDialog passwordDialog(this);
    passwordDialog.setWindowTitle("Change Password");
    QFormLayout passwordLayout(&passwordDialog);

    QLineEdit* currentPassword = new QLineEdit();
    currentPassword->setEchoMode(QLineEdit::Password);
    passwordLayout.addRow("Current Password:", currentPassword);

    QLineEdit* newPassword = new QLineEdit();
    newPassword->setEchoMode(QLineEdit::Password);
    passwordLayout.addRow("New Password:", newPassword);

    QLineEdit* confirmPassword = new QLineEdit();
    confirmPassword->setEchoMode(QLineEdit::Password);
    passwordLayout.addRow("Confirm Password:", confirmPassword);

    QDialogButtonBox* buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
    passwordLayout.addWidget(buttonBox);

    connect(buttonBox, &QDialogButtonBox::accepted, &passwordDialog, [this, currentPassword, newPassword, confirmPassword]() {
        if (newPassword->text() != confirmPassword->text()) {
            QMessageBox::warning(this, "Error", "Passwords do not match!");
            return;
        }

        if (User::validateUserPassword(currentUser.toStdString(), currentPassword->text().toStdString())) {
            if (User::updateUserPassword(currentUser.toStdString(), newPassword->text().toStdString())) {
                QMessageBox::information(this, "Success", "Password updated successfully!");
            } else {
                QMessageBox::warning(this, "Error", "Failed to update password.");
            }
        } else {
            QMessageBox::warning(this, "Error", "Current password is incorrect.");
        }
    });

    connect(buttonBox, &QDialogButtonBox::rejected, &passwordDialog, &QDialog::reject);

    passwordDialog.exec();
}

void AccountWindow::loadReservations() {
    while (QLayoutItem* item = reservationLayout->takeAt(0)) {
        if (item->widget()) {
            delete item->widget();
        }
        delete item;
    }

    bool hasReservations = false;

    for (const auto& eq : manager.getInventory()) {
        if (eq->getReservedBy() == currentUser.toStdString()) {
            hasReservations = true;

            QHBoxLayout* itemLayout = new QHBoxLayout();

            QLabel* nameLabel = new QLabel(QString::fromStdString(eq->getName()));
            itemLayout->addWidget(nameLabel);

            QPushButton* cancelButton = new QPushButton("Cancel Reservation");
            connect(cancelButton, &QPushButton::clicked, this, [this, nameLabel]() {
                cancelReservation(nameLabel->text());
            });
            itemLayout->addWidget(cancelButton);

            reservationLayout->addLayout(itemLayout);
        }
    }

    if (!hasReservations) {
        QLabel* noReservationsLabel = new QLabel("No reservations found.");
        noReservationsLabel->setAlignment(Qt::AlignCenter);
        reservationLayout->addWidget(noReservationsLabel);
    }

    ui->scrollAreaWidgetContents->setLayout(reservationLayout);
}

void AccountWindow::cancelReservation(const QString& itemName) {
    bool reservationFound = false;

    for (auto eq : manager.getInventory()) {
        if (QString::fromStdString(eq->getName()) == itemName && eq->getReservedBy() == currentUser.toStdString()) {
            eq->makeAvailable();
            eq->setReservedBy("");
            reservationFound = true;
            break;
        }
    }

    if (reservationFound) {
        for (int i = 0; i < reservationLayout->count(); ++i) {
            QLayoutItem* item = reservationLayout->itemAt(i);
            if (item) {
                QHBoxLayout* rowLayout = dynamic_cast<QHBoxLayout*>(item->layout());
                if (rowLayout) {
                    QLabel* nameLabel = dynamic_cast<QLabel*>(rowLayout->itemAt(0)->widget());
                    if (nameLabel && nameLabel->text() == itemName) {
                        while (QLayoutItem* childItem = rowLayout->takeAt(0)) {
                            delete childItem->widget();
                            delete childItem;
                        }
                        delete rowLayout;
                        reservationLayout->removeItem(item);
                        break;
                    }
                }
            }
        }
        if (reservationLayout->count() == 0) {
            QLabel* noReservationsLabel = new QLabel("No reservations found.");
            noReservationsLabel->setAlignment(Qt::AlignCenter);
            reservationLayout->addWidget(noReservationsLabel);
        }
        // refresh main window
        if (mainWindow) {
            mainWindow->displayInventory(manager.getInventory());
        }
        // send notifcations
        NotificationManager::getInstance()->addNotification(
            "\n\nReservation for \"" + itemName.toStdString() + "\" has been canceled."
            );

        QMessageBox::information(this, "Cancel Reservation", "Reservation cancelled successfully!");
    } else {
        QMessageBox::warning(this, "Cancel Reservation", "Item not found.");
    }
}

void AccountWindow::on_closeButton_clicked() {
    close();
}

// Public methods for test access
void AccountWindow::triggerLoadNotifications() {
    loadNotifications();
}

QListWidget* AccountWindow::getNotificationsList() const {
    return notificationsList;
}



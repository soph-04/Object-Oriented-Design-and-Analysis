#ifndef NOTIFICATION_MANAGER_H
#define NOTIFICATION_MANAGER_H

#include <string>
#include <vector>
#include <mutex>

#include "subject.h"

class NotificationManager : public Subject {
private:
    static NotificationManager* instance;
    static std::mutex instanceMutex;

    std::vector<std::string> notifications;

    // contrustor to ensure Singleton
    NotificationManager() {}

public:
    NotificationManager(const NotificationManager&) = delete;
    NotificationManager& operator=(const NotificationManager&) = delete;

    // singleton access
    static NotificationManager* getInstance();

    void addNotification(const std::string& message);
    const std::vector<std::string>& getNotifications() const;

    void clearNotifications();
};

#endif // NOTIFICATION_MANAGER_H

#include <QDebug>

#include "notification_manager.h"

NotificationManager* NotificationManager::instance = nullptr;
std::mutex NotificationManager::instanceMutex;

// singleton pattern to get a single instace of notificationmanager
NotificationManager* NotificationManager::getInstance() {
    // thread-safe implementation
    std::lock_guard<std::mutex> lock(instanceMutex);
    // create new instance if one doesnt exist
    if (!instance) {
        qDebug() << "Creating NotificationManager singleton instance.";
        instance = new NotificationManager();
    } else {
        qDebug() << "Returning existing NotificationManager singleton instance.";
    }
    return instance;
}

// add new notification to list
void NotificationManager::addNotification(const std::string& message) {
    qDebug() << "Adding notification:" << QString::fromStdString(message);
    notifications.push_back(message);
    notify(message);
}

// get all stored notifications
const std::vector<std::string>& NotificationManager::getNotifications() const {
    qDebug() << "Fetching all notifications. Total notifications:" << notifications.size();
    return notifications;
}

// clear stored notifications
void NotificationManager::clearNotifications() {
    notifications.clear();
    qDebug() << "Notifications cleared.";
}


#ifndef EQUIPMENTDETAILS_H
#define EQUIPMENTDETAILS_H

#include <QMainWindow>

#include "equipment.h"

namespace Ui {
class EquipmentDetails;
}

// provides a detailed view of specific equipment, allowing users to make reservations, view equipment properties and interact with the system
class EquipmentDetails : public QMainWindow {
    Q_OBJECT

public:
    explicit EquipmentDetails(Equipment* equipment, const QString& userRole, const QString& userName, QWidget* parent = nullptr);
    ~EquipmentDetails();

signals:
    void reservationMade(Equipment* equipment);

private slots:
    void handleReservationRequest();

private:
    bool confirmReservation(const QDate& startDate, const QDate& endDate, const QString& pickupTime);
    void completeReservation(const QDate& startDate, const QDate& endDate, const QString& pickupTime);

    Ui::EquipmentDetails *ui;
    Equipment* equipment;
    QString currentRole;
    QString currentUser;

    static int reservationCounter;
};

#endif // EQUIPMENTDETAILS_H

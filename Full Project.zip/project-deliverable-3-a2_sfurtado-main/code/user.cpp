#include <algorithm>

#include "user.h"
#include "qcontainerfwd.h"
#include "qdebug.h"
#include "qlogging.h"

std::vector<std::unique_ptr<User>> User::users;
std::string User::filePath = ":/resources/users";

// load users from csv
bool User::loadUsers() {
    std::ifstream file(filePath);
    if (!file.is_open()) {
        qDebug() << "Unable to open file:" << QString::fromStdString(filePath);
        return false;
    }

    qDebug() << "Loading users from file...";
    users.clear();

    std::string line;
    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string uname, pass, role;
        if (std::getline(ss, uname, ',') && std::getline(ss, pass, ',') && std::getline(ss, role, ',')) {
            // trim whitespace
            uname.erase(uname.find_last_not_of(" \n\r\t") + 1);
            pass.erase(pass.find_last_not_of(" \n\r\t") + 1);
            role.erase(role.find_last_not_of(" \n\r\t") + 1);

            // add user based on role
            if (role == "Member") {
                users.push_back(std::make_unique<Member>(uname, pass));
            } else if (role == "Clerk") {
                users.push_back(std::make_unique<Clerk>(uname, pass));
            }
        } else {
            qDebug() << "Skipping malformed line:" << QString::fromStdString(line);
        }
    }

    file.close();
    qDebug() << "Users loaded successfully. Total users:" << users.size();
    return true;
}

// save users to csv
bool User::saveUsers() {
    std::ofstream file(filePath);
    if (!file.is_open()) {
        std::cerr << "Unable to open file for writing: " << filePath << std::endl;
        return false;
    }

    file << "Username,Password,Role\n";
    for (const auto& user : users) {
        file << user->getUsername() << "," << user->password << "," << user->getRole() << "\n";
    }

    file.close();
    return true;
}

// find users by their username
User* User::findUser(const std::string& uname) {
    for (const auto& user : users) {
        // case-insensitive comparison
        if (QString::fromStdString(user->getUsername()).compare(QString::fromStdString(uname), Qt::CaseInsensitive) == 0) {
            return user.get();
        }
    }
    qDebug() << "User not found:" << QString::fromStdString(uname);
    return nullptr;
}

// validate user's username and password
bool User::validateUserPassword(const std::string& uname, const std::string& pass) {
    User* user = findUser(uname);
    if (user) {
        // check that username and password match
        return user->login(uname, pass);
    }
    // user not found
    return false;
}

// update user password
bool User::updateUserPassword(const std::string& uname, const std::string& newPass) {
    User* user = findUser(uname);
    if (user) {
        // update password in memory
        user->password = newPass;
        return saveUsers();
    }
    return false;
}

// add a new user to the list
void User::addUser(const std::string& uname, const std::string& pass, const std::string& role) {
    if (findUser(uname)) {
        std::cerr << "User already exists: " << uname << std::endl;
        return;
    }

    if (role == "Member") {
        users.push_back(std::make_unique<Member>(uname, pass));
    } else if (role == "Clerk") {
        users.push_back(std::make_unique<Clerk>(uname, pass));
    }

    saveUsers();
}

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <stack>
#include <vector>

#include "inventory_manager.h"
#include "ui_mainwindow.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(const QString& username, const QString& role, QWidget *parent = nullptr);
    ~MainWindow();

    void displayInventory(const std::vector<Equipment*>& equipmentList);
    QTableWidget* getEquipmentTable() const { return ui->equipmentTable; }

private:
    Ui::MainWindow *ui;
    // pointer to singleton instance
    InventoryManager* manager;

    QString currentUser;
    QString currentRole;

    std::stack<std::vector<Equipment*>> navigationHistory;

    void populateInventory();
    void populateCategoryComboBox();
    void viewEquipmentDetails(Equipment* eq);
    void resetUI();

private slots:
    void on_searchButton_clicked();
    void on_categoryComboBox_currentIndexChanged(int index);

    void on_accountButton_clicked();
    void on_backButton_clicked();
    void onReservationMade(Equipment* equipment);

    // Clerk-specific actions
    void on_addButton_clicked();
    void on_editButton_clicked();
    void on_removeButton_clicked();

    void on_logReturnButton_clicked();
    void on_logDamageButton_clicked();
    void on_checkPickupButton_clicked();
};

#endif // MAINWINDOW_H
